package com.bitlabs.Arogya;

public class App {

    public static void main(String [] args) {
    Daointerface dao=new DaoImpl();
    Patient p=new Patient();
    
    p.setId(104);
    p.setAge(50);
    p.setName("prasad");
    p.setGender("male");
    p.setCity("visanapetta");
    p.setAddress("6-876,visanapetta");
    p.setGuardian_name("srinu");
    p.setGuardian_address("4-98");
    p.setDateOfAdmission("2000/05/28");
    p.setAadhar_Card_number(92345);
    p.setContact_number(45678);
    p.setGuardian_contactNumber(7654);
    
    //dao.patientRegistration(p);
    
    
    //dao.viewAllPatient();
    
    //dao.searchPatientById(102);
    
    //dao.deletePatientById(101);
    
   // dao.searchPatientByCity("guntur");
    
    dao.searchPatientByAgeGroup(18, 55);
    
}

}
